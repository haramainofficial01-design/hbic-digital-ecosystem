"""Vector/PDF signage artwork and measured-plane photo compositing, no generated images."""
from pathlib import Path
import base64, html, json, math, subprocess, tempfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps
import qrcode, zxingcpp
from fontTools.ttLib import TTFont as VarFont
from fontTools.varLib.instancer import instantiateVariableFont
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from pypdf import PdfReader

root=Path(__file__).resolve().parents[1]
cfg=json.loads((root/'measurements/Entrance.json').read_text())
door=cfg['door_mm']; edge=cfg['edge_mm']; bleed=cfg['print']['bleed_mm']; safe=cfg['print']['type_safe_mm']
mm=72/25.4
BRAND={'navy':'#082845','ink':'#122F45','cream':'#F8F5EC','white':'#FFFFFF','teal':'#075B62','blue':'#07578B','gold':'#BA933F','lightgold':'#E3C478','mist':'#DCE8E8','soft':'#52656C','pale':'#D6E6EB'}
F={'regular':('Inter',400,14),'medium':('Inter',550,14),'bold':('Inter',720,24),'display':('Newsreader',450,68),'display-semibold':('Newsreader',550,68)}
logo=root/'brand/HBIC Official Logo.png'
links={'App':'https://hbic.ca/download','Website':'https://hbic.ca','Prayer times':'https://hbic.ca/prayer-times'}
qr={}
fonts={}
for key,(family,weight,optical) in F.items():
    dst=root/'brand'/f'HBIC {key}.ttf'
    if not dst.exists():
        font=VarFont(root/'brand'/f'{family} Variable.ttf')
        vals={a.axisTag:{'opsz':optical,'wght':weight}.get(a.axisTag,a.defaultValue) for a in font['fvar'].axes}
        instantiateVariableFont(font,vals,inplace=True)
        # PDF subsets must not share an internal face name across weights.
        display_name = 'HBIC '+key.title().replace('-', ' ')
        for rec in font['name'].names:
            if rec.nameID in (1, 4, 6, 16):
                name = display_name.replace(' ', '-') if rec.nameID == 6 else display_name
                font['name'].setName(name,rec.nameID,rec.platformID,rec.platEncID,rec.langID)
            elif rec.nameID in (2, 17):
                font['name'].setName('Regular',rec.nameID,rec.platformID,rec.platEncID,rec.langID)
        font.save(dst)
    fonts[key]=dst
    pdfmetrics.registerFont(TTFont(key,str(dst)))
for key,url in links.items():
    code=qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,box_size=1,border=cfg['print']['qr_border_modules']);code.add_data(url);code.make(fit=True);qr[key]=code.get_matrix()

def col(color):
    return BRAND.get(color,color)
def hx(color):
    return colors.HexColor(col(color))

class Page:
    def __init__(self,w,h,bg='cream',shape=None,name=''):
        self.w,self.h,self.bg,self.name=w,h,bg,name
        self.shape=shape or [(0,0),(w,0),(w,h),(0,h)]
        self.ops=[]; self.text_boxes=[]; self.qrs=[]
    def rect(self,x,y,w,h,fill): self.ops.append(('rect',x,y,w,h,fill))
    def line(self,pts,color,width=1): self.ops.append(('line',pts,color,width))
    def text(self,x,y,label,size,font='regular',color='navy',align='left',track=0):
        width=pdfmetrics.stringWidth(label,font,size)+max(0,len(label)-1)*track
        x-=width*(.5 if align=='center' else 1 if align=='right' else 0)
        self.text_boxes.append((label,x,y-size*.87,x+width,y+size*.24))
        self.ops.append(('text',x,y,label,size,font,color,track))
    def image(self,x,y,size,path=logo): self.ops.append(('image',x,y,size,path))
    def qr(self,x,y,size,key):
        self.ops.append(('qr',x,y,size,key)); self.qrs.append((x,y,size,key))

def dimensions(which,side):
    left=side=='Left'
    w=door['left_width' if left else 'right_width']-edge['outside']-edge['seam_each_side']
    top=cfg[which]['top_mm']; bottom=cfg[which]['bottom_mm']; h=bottom-top
    assert top>=max(edge['top_minimum'],cfg['hardware_mm']['left_unit_26']['keep_clear_until_y'])
    assert bottom<=door['height']-edge['bottom_minimum']
    return w,h,top,edge['outside' if left else 'seam_each_side']

def notch_ranges(which,side):
    if side=='Left':return []
    w,h,top,x0=dimensions(which,side); out=[]
    for key in ['right_handle','right_bottom_hardware']:
        d=cfg['hardware_mm'][key]
        a=max(0,d['keep_clear_top']-top); b=min(h,d['keep_clear_bottom']-top); x=d['keep_clear_x_to']-x0
        if b>a and x>0:
            assert x<w and a>0, 'Panel intersects an exclusion in its top/right edge; revise the install zone.'
            out.append((a,b,x))
    return out

def trim_shape(w,h,notches):
    p=[(0,0),(w,0),(w,h)]
    for a,b,x in reversed(notches):
        if b<h:p.extend([(0,b),(x,b)])
        else:p.append((x,b))
        p.extend([(x,a),(0,a)])
    if not notches or notches[-1][1]!=h:p.insert(3,(0,h))
    return p

styles={
    '01 Editorial':dict(left='cream',right='navy',inkL='navy',inkR='cream',softL='soft',softR='pale',accentL='teal',accentR='lightgold'),
    '02 Threshold':dict(left='navy',right='teal',inkL='cream',inkR='cream',softL='pale',softR='mist',accentL='lightgold',accentR='lightgold'),
    '03 Wayfinding':dict(left='cream',right='mist',inkL='navy',inkR='navy',softL='soft',softR='teal',accentL='teal',accentR='teal')
}
selected='01 Editorial'
def layout(which,side,style=selected):
    w,h,top,x0=dimensions(which,side)
    notches=notch_ranges(which,side)
    left=side=='Left'; full=which=='full'; st=styles[style]
    p=Page(w,h,st[side.lower()],trim_shape(w,h,notches),f'{which} {side} {style}')
    ink=st['inkL' if left else 'inkR']; quiet=st['softL' if left else 'softR']; accent=st['accentL' if left else 'accentR']
    # Six columns per leaf; align cap baselines and divider across both leaves.
    g=55; W=w-g*2; module=W/6; mode=style[:2]
    head=117; split=157
    # Shared name intentionally reads across the seam; both words fit on their own leaf.
    if left:
        p.image(g-4,37,121)
        p.text(w-g,head,'HAZRAT BILAL',34,'bold',ink,'right',1.8)
    else:
        p.text(g,head,'ISLAMIC CENTRE',34,'bold',ink,'left',1.8)
    p.line([(g,split),(w-g,split)],'gold' if mode!='03' else 'teal',1.65)
    if mode=='02':
        # Repeated lintel geometry references the building threshold, not a background texture.
        x=w-g-5; y=320 if left else 235
        for a in [0,11,22]:
            p.line([(x-126+a,y+145),(x-126+a,y+38+a),(x-82+a,y+a),(x,y+a)],'gold',.85)
    if left:
        p.text(g,240 if not full else 285,'MASJID BILAL  /  CALGARY',30,'bold',accent,track=2)
        if mode=='03':
            p.text(g,406 if not full else 515,'A place to',105,'bold',ink,track=-4)
            p.text(g,532 if not full else 650,'belong.',125,'bold',ink,track=-5)
        else:
            # Fixed two-line title, independent of seam.
            p.text(g,407 if not full else 535,'A place',145 if not full else 157,'display',ink,track=-4)
            p.text(g,562 if not full else 705,'to belong.',145 if not full else 157,'display',ink,track=-4)
        p.text(g,658 if not full else 852,'Prayer. Learning. Community.',33,'medium',ink,track=-.4)
        p.text(g,713 if not full else 915,'5 DAILY PRAYERS & JUMU’AH',22,'bold',accent,track=1.5)
        if full:
            p.line([(g,1015),(w-g,1015)],'gold',1.2)
            p.text(g,1100,'Visit Masjid Bilal',39,'medium',ink)
            p.text(g,1170,'20 Saddlestone Dr',24,'regular',quiet)
            p.text(g,1211,'Calgary, AB T3J 0B4',24,'regular',quiet)
            for a in [0,20,40]:
                p.line([(w-g-40-a,1306),(w-g-40-a,1096-a),(w-g-135-a,1001-a)],'gold',1.2)
        foot=h-(236 if full else 237)
        p.line([(g,foot),(w-g,foot)],'gold' if mode!='03' else 'teal',1.2)
        p.text(g,foot+103,'hbic.ca',84,'bold',ink,track=-4.5)
        p.text(g,foot+159,'587-917-0333   ·   info@hbic.ca',19,'medium',quiet)
        if not full:p.text(g,foot+194,'20 Saddlestone Dr  ·  Calgary, AB T3J 0B4',17,'regular',quiet)
        p.qr(w-g-107,foot+47,107,'Website')
        p.text(w-g-53.5,foot+180,'hbic.ca',16,'medium',ink,'center')
    else:
        base=243 if not full else 260
        p.text(g,base,'OFFICIAL MASJID BILAL APP',22,'bold',accent,track=1.5)
        if mode=='03':
            p.text(g,base+115,'Get the app.',91,'bold',ink,track=-4)
            p.text(g,base+179,'Your masjid, wherever you are.',31,'medium',ink)
        else:
            p.text(g,base+105,'Your masjid,',95 if mode=='01' else 84,'display',ink,track=-2)
            p.text(g,base+193,'wherever you are.',95 if mode=='01' else 84,'display',ink,track=-2)
        p.text(g,base+251,'Live prayer times  ·  Alerts  ·  Community updates',25,'regular',quiet)
        qrY=base+(320 if full else 332); x1=g; x2=g+module*3.12
        p.text(x1,qrY-24,'Download the app',26,'bold',ink)
        p.text(x2,qrY-24,'Prayer times',26,'bold',ink)
        p.qr(x1,qrY,122,'App'); p.qr(x2,qrY+10,112,'Prayer times')
        p.text(x1,qrY+151,'hbic.ca/download',17,'medium',ink)
        p.text(x2,qrY+151,'hbic.ca/prayer-times',17,'medium',ink)
        p.text(x1,qrY+181,'iPhone and Android',17,'regular',quiet)
        p.text(x2,qrY+181,'Daily prayers & Jumu’ah',17,'regular',quiet)
        if full:
            # Empty around handle; quiet movement from utility to community.
            foot=h-453
            p.line([(max(g,notches[0][2]+safe) if notches else g,foot),(w-g,foot)],'gold',1)
            tx=max(g,max((n[2] for n in notches),default=0)+safe)
            p.text(tx,foot+75,'Follow HBIC Youth',34,'medium',ink)
            p.text(tx,foot+132,'Instagram   @hbicyouth',23,'regular',quiet)
            p.text(tx,foot+179,'YouTube     @hbicyouth',23,'regular',quiet)
            p.text(tx,foot+226,'TikTok       @bilalyouth',23,'regular',quiet)
            p.text(tx,foot+324,'587-917-0333  ·  info@hbic.ca',19,'medium',ink)
        else:
            foot=h-135; tx=max(g,max((n[2] for n in notches),default=0)+safe)
            p.line([(tx,foot),(w-g,foot)],'gold',1)
            p.text(tx,foot+40,'HBIC YOUTH',17,'bold',accent,track=1.8)
            p.text(tx,foot+74,'Instagram & YouTube  @hbicyouth',17,'regular',quiet)
            p.text(tx,foot+102,'TikTok  @bilalyouth',17,'regular',quiet)
    for label,x1,y1,x2,y2 in p.text_boxes+[(key,x,y,x+s,y+s) for x,y,s,key in p.qrs]:
        assert x1>=safe-1 and x2<=w-safe+1 and y1>=safe-2 and y2<=h-20, (p.name,label,(x1,y1,x2,y2),w,h)
        assert all(not(y2>a and y1<b and x1<x+18) for a,b,x in notches),(p.name,label,'hardware',notches,(x1,y1,x2,y2))
    return p

def run_spans(matrix):
    for j,row in enumerate(matrix):
        i=0
        while i<len(row):
            if not row[i]: i+=1;continue
            start=i
            while i<len(row) and row[i]: i+=1
            yield start,j,i-start

def draw(c,p,ox=0,oy=0,scale=1,clip=True,extra=0):
    c.saveState();c.translate(ox,oy);c.scale(scale,scale)
    def path(points,close=False):
        pp=c.beginPath();pp.moveTo(points[0][0],p.h-points[0][1])
        for x,y in points[1:]:pp.lineTo(x,p.h-y)
        if close:pp.close()
        return pp
    if clip:c.clipPath(path(p.shape,True),stroke=0)
    c.setFillColor(hx(p.bg));c.rect(-extra,-extra,p.w+extra*2,p.h+extra*2,fill=1,stroke=0)
    for op in p.ops:
        kind,*a=op
        if kind=='rect':
            x,y,w,h,color=a;c.setFillColor(hx(color));c.rect(x,p.h-y-h,w,h,stroke=0,fill=1)
        if kind=='line':
            pts,color,weight=a;c.setStrokeColor(hx(color));c.setLineWidth(weight);c.drawPath(path(pts))
        if kind=='image':
            x,y,s,f=a;c.drawImage(str(f),x,p.h-y-s,s,s,mask='auto')
        if kind=='text':
            x,y,label,size,font,color,track=a;c.setFillColor(hx(color));t=c.beginText(x,p.h-y);t.setFont(font,size);t.setCharSpace(track);t.textOut(label);c.drawText(t)
        if kind=='qr':
            x,y,s,key=a;m=qr[key];u=s/len(m)
            c.setFillColorCMYK(0,0,0,0);c.rect(x,p.h-y-s,s,s,fill=1,stroke=0)
            c.setFillColorCMYK(0,0,0,1)
            for i,j,span in run_spans(m):c.rect(x+i*u,p.h-y-(j+1)*u,span*u,u,fill=1,stroke=0)
    c.restoreState()

def export_pdf(p,out,printing=False):
    b=bleed if printing else 0
    c=canvas.Canvas(str(out),pagesize=((p.w+b*2)*mm,(p.h+b*2)*mm),pageCompression=1)
    c.setTitle(p.name+' | HBIC')
    if printing:
        c.setTrimBox((b*mm,b*mm,(p.w+b)*mm,(p.h+b)*mm))
        c.setBleedBox((0,0,(p.w+2*b)*mm,(p.h+2*b)*mm))
    draw(c,p,b*mm,b*mm,mm,clip=not printing,extra=b)
    c.showPage();c.save()

def svg(p,out):
    fs=[];defined=set()
    for t in p.ops:
        if t[0]=='text' and t[5] not in defined:
            key=t[5];defined.add(key)
            fs.append(f"@font-face{{font-family:'HBIC-{key}';src:url(data:font/ttf;base64,{base64.b64encode(fonts[key].read_bytes()).decode()}) format('truetype');}}")
    points=' '.join(f'{x},{y}' for x,y in p.shape)
    s=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{p.w}mm" height="{p.h}mm" viewBox="0 0 {p.w} {p.h}"><title>{html.escape(p.name)}</title><defs><style>{"".join(fs)}</style><clipPath id="trim"><polygon points="{points}"/></clipPath></defs><g clip-path="url(#trim)"><rect width="{p.w}" height="{p.h}" fill="{col(p.bg)}"/>']
    for kind,*a in p.ops:
        if kind=='text':
            x,y,label,size,font,color,track=a;s.append(f'<text x="{x}" y="{y}" font-family="HBIC-{font}" font-size="{size}" letter-spacing="{track}" fill="{col(color)}">{html.escape(label)}</text>')
        if kind=='line':
            pts,color,weight=a;s.append(f'<polyline points="{" ".join(f"{x},{y}" for x,y in pts)}" fill="none" stroke="{col(color)}" stroke-width="{weight}"/>')
        if kind=='rect':
            x,y,w,h,color=a;s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{col(color)}"/>')
        if kind=='image':
            x,y,size,f=a;s.append(f'<image x="{x}" y="{y}" width="{size}" height="{size}" href="data:image/png;base64,{base64.b64encode(f.read_bytes()).decode()}"/>')
        if kind=='qr':
            x,y,size,key=a;s.append(qr_svg_group(key,x,y,size))
    out.write_text(''.join(s)+'</g></svg>')

def qr_svg_group(key,x,y,s):
    m=qr[key];n=len(m);d=''.join(f'M{i} {j}h{span}v1h-{span}Z' for i,j,span in run_spans(m))
    return f'<g transform="translate({x} {y}) scale({s/n})"><title>{html.escape(links[key])}</title><rect width="{n}" height="{n}" fill="white"/><path d="{d}" fill="black" shape-rendering="crispEdges"/></g>'

def render(pdf,stem,dpi):
    subprocess.run(['pdftoppm','-png','-r',str(dpi),'-singlefile',str(pdf),str(stem)],check=True)
    return Image.open(str(stem)+'.png').convert('RGB')

def pair_pdf(left,right,out):
    gap=door['centre_gap']+edge['seam_each_side']*2
    c=canvas.Canvas(str(out),pagesize=((left.w+right.w+gap)*mm,left.h*mm),pageCompression=1)
    c.setTitle('HBIC | A place to belong. | Combined proof')
    c.setFillColor(hx('#514C48'));c.rect(0,0,(left.w+right.w+gap)*mm,left.h*mm,fill=1,stroke=0)
    draw(c,left,0,0,mm);draw(c,right,(left.w+gap)*mm,0,mm);c.showPage();c.save()

def homography(source,dest):
    A=[];B=[]
    for (x,y),(u,v) in zip(source,dest):
        A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);B.extend([u,v])
    return np.r_[np.linalg.solve(np.array(A,float),np.array(B,float)),1].reshape((3,3))
def points(T,pts):
    a=np.c_[np.array(pts),np.ones(len(pts))]@T.T
    return a[:,:2]/a[:,2:3]
def warp(im,H,size):
    z=np.linalg.inv(H);z/=z[2,2]
    return im.transform(size,Image.Transform.PERSPECTIVE,tuple(z.flatten()[:8]),Image.Resampling.BICUBIC)

def photo_clean(photo,geo):
    # Clone nearby real door pixels in the rectified plane. Only the poster area
    # is retouched to represent removal; original photographs remain untouched.
    canvas_size=(450,1015);quad=[(0,0),(450,0),(450,1015),(0,1015)]
    H=homography(geo['left'],quad)
    flat=warp(photo,H,canvas_size).convert('RGBA')
    poly=points(H,geo['old_poster']);xx,yy=poly[:,0],poly[:,1]
    x0,y0=max(2,math.floor(xx.min())-4),max(2,math.floor(yy.min())-4)
    x1,y1=min(448,math.ceil(xx.max())+4),min(1013,math.ceil(yy.max())+4)
    sample=flat.crop((max(5,x0),min(920,y1+19),min(445,x1),991)).resize((x1-x0,y1-y0),Image.Resampling.BICUBIC)
    overlay=Image.new('RGBA',canvas_size);overlay.paste(sample,(x0,y0))
    mask=Image.new('L',canvas_size);ImageDraw.Draw(mask).polygon([(float(x),float(y)) for x,y in poly],fill=255)
    mask=mask.filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.GaussianBlur(1.4));overlay.putalpha(mask)
    return Image.alpha_composite(photo.convert('RGBA'),warp(overlay,np.linalg.inv(H),photo.size))

def mock(photo_file,pages,pngs,which):
    geo=cfg['photos'][photo_file]
    photo=Image.open(root/'references'/photo_file).convert('RGB')
    staged=photo_clean(photo,geo)
    for side,p,im in zip(['Left','Right'],pages,pngs):
        w,h,top,x=dimensions(which,side)
        dw=door[side.lower()+'_width']; dh=door['height']
        T=homography([(0,0),(dw,0),(dw,dh),(0,dh)],geo[side.lower()])
        raster=im.convert('RGBA')
        # Prefilter artwork before projecting onto the photo to avoid aliasing
        # the type and rules when mapping a large vector render to a small door.
        raster.thumbnail((1000,1200),Image.Resampling.LANCZOS)
        rw,rh=raster.size
        alpha=Image.new('L',raster.size)
        ImageDraw.Draw(alpha).polygon([(a/w*(rw-1),b/h*(rh-1)) for a,b in p.shape],fill=255)
        # Small gain for the warm site light; artwork texture is intentionally matte.
        arr=np.asarray(raster).copy(); arr[:,:,:3]=(arr[:,:,:3].astype(float)*np.array([.95,.94,.91])).clip(0,255).astype('uint8')
        raster=Image.fromarray(arr);raster.putalpha(alpha)
        src=[(0,0),(rw,0),(rw,rh),(0,rh)]
        dest=points(T,[(x,top),(x+w,top),(x+w,top+h),(x,top+h)])
        staged=Image.alpha_composite(staged,warp(raster,homography(src,dest),photo.size))
    return staged.convert('RGB')

def guide(which,out):
    dh=door['height']; width=door['left_width']+door['centre_gap']+door['right_width']; W,H=(width+160,dh+190)
    c=canvas.Canvas(str(out),pagesize=(W*mm,H*mm),pageCompression=1)
    c.setTitle(f'{which.title()} | provisional trim and hardware overlay')
    c.translate(80*mm,135*mm);c.scale(mm,mm)
    c.setStrokeColor(hx('soft'));c.setLineWidth(1)
    for side,dx in [('Left',0),('Right',door['left_width']+door['centre_gap'])]:
        c.rect(dx,0,door[side.lower()+'_width'],dh,stroke=1,fill=0)
        p=layout(which,side); w,h,top,x=dimensions(which,side)
        pth=c.beginPath();pth.moveTo(dx+x+p.shape[0][0],dh-top-p.shape[0][1])
        for a,b in p.shape[1:]:pth.lineTo(dx+x+a,dh-top-b)
        pth.close()
        c.setStrokeColor(hx('teal'));c.setLineWidth(2.6);c.drawPath(pth)
        c.setFillColor(hx('navy'));c.setFont('bold',34);c.drawCentredString(dx+x+w/2,dh-top-170,side.upper()+f'  {w} × {h} mm')
        c.setFont('regular',26);c.drawCentredString(dx+x+w/2,dh-top-225,f'Panel top {top} mm below leaf top')
    dx=door['left_width']+door['centre_gap']
    for key,label in [('right_handle','HANDLE CLEARANCE'),('right_bottom_hardware','LOWER HARDWARE')]:
        d=cfg['hardware_mm'][key];c.setStrokeColor(hx('gold'));c.setDash(7,5);c.rect(dx,dh-d['keep_clear_bottom'],d['keep_clear_x_to'],d['keep_clear_bottom']-d['keep_clear_top'],stroke=1,fill=0);c.setDash()
        c.setFillColor(hx('navy'));c.setFont('bold',17);c.drawString(dx+10,dh-d['keep_clear_top']-32,label)
    c.setFillColor(hx('navy'));c.setFont('bold',32);c.drawString(0,-55,f'{which.upper()} INSTALLATION / 1:1 PROVISIONAL • DO NOT CUT FROM PHOTO ESTIMATES')
    c.setFont('regular',20);c.drawString(0,-95,'Green = trim contour. Gold = keep clear. Gray = leaf edges. No media on frame, glass, seam or hardware.')
    c.showPage();c.save()

def a4_proof(pages,out):
    # All measured in mm. Exact 1:1 assembly windows after two scaled overview pages.
    c=canvas.Canvas(str(out),pagesize=(210*mm,297*mm),pageCompression=1)
    c.setTitle('HBIC entrance | A4 size and tiled proof')
    def title(a,b):
        c.setFillColor(hx('navy'));c.setFont('bold',13);c.drawString(12*mm,281*mm,a)
        c.setFont('regular',8);c.drawString(12*mm,274*mm,b)
    for which in ('wide','full'):
        left,right=pages[which];gap=door['centre_gap']+2*edge['seam_each_side']
        title(which.title()+' | complete scaled proof','1:10 overview. Print at Actual size / 100%, never Fit.')
        s=mm/10; x=(210-(left.w+right.w+gap)/10)/2*mm;y=250*mm-left.h*s
        c.setFillColor(hx('navy'));c.rect(x,y,(left.w+right.w+gap)*s,left.h*s,fill=1,stroke=0)
        draw(c,left,x,y,s);draw(c,right,x+(left.w+gap)*s,y,s)
        c.setStrokeColor(hx('teal'));c.line(14*mm,32*mm,64*mm,32*mm);c.setFont('regular',8);c.drawString(14*mm,25*mm,'50 mm page-scale check');c.showPage()
    tileW,tileH=188,248; overlap=8; pitchW,pitchH=tileW-overlap,tileH-overlap
    for idx,p in enumerate(pages['wide']):
        name=('LEFT','RIGHT')[idx]
        form=name+'1to1'
        c.beginForm(form,0,0,p.w*mm,p.h*mm);draw(c,p,0,0,mm);c.endForm()
        cols=max(1,math.ceil((p.w-overlap)/pitchW));rows=max(1,math.ceil((p.h-overlap)/pitchH))
        for r in range(rows):
            for j in range(cols):
                title(f'WIDE / {name} / Row {r+1} of {rows} / Column {j+1} of {cols}', '1:1 trial only. Actual size (100%). Align tile edges with 8 mm overlap.')
                x,y=11*mm,15*mm
                c.saveState();cl=c.beginPath();cl.rect(x,y,tileW*mm,tileH*mm);c.clipPath(cl,stroke=0)
                c.translate(x-j*pitchW*mm,y+(tileH-p.h+r*pitchH)*mm);c.doForm(form);c.restoreState()
                c.setLineWidth(.45);c.setStrokeColor(colors.black)
                for i in (0,tileW):
                    for k in (0,tileH):
                        xx,yy=x+i*mm,y+k*mm;c.line(xx-2*mm,yy,xx+2*mm,yy);c.line(xx,yy-2*mm,xx,yy+2*mm)
                c.line(12*mm,8*mm,62*mm,8*mm);c.setFont('regular',7);c.drawString(66*mm,7*mm,'50 mm ruler check')
                c.showPage()
    c.save()

def schedule():
    p=Page(297,210,'cream',name='Replaceable Jumu’ah schedule | A4 landscape')
    p.image(17,11,27)
    p.text(49,28,'MASJID BILAL',7.2,'bold',track=.5)
    p.line([(17,43),(280,43)],'gold',.55)
    p.text(17,67,'Jumu’ah',21,'display')
    p.text(280,64,'EFFECTIVE FRIDAY, 13 NOVEMBER 2026',5.1,'bold','teal','right',.32)
    p.text(17,91,'FIRST KHUTBAH',6.2,'bold','teal',track=.55)
    p.text(152,91,'SECOND KHUTBAH',6.2,'bold','teal',track=.55)
    p.text(17,123,'1:30 PM',28,'bold',track=-.8)
    p.text(152,123,'2:15 PM',28,'bold',track=-.8)
    p.rect(17,137,263,28,'navy');p.text(24,155,'FIRST JUMU’AH DOORS CLOSE AT 1:45 PM',8.7,'bold','white')
    p.text(17,179,'Doors close due to City capacity restrictions. Please arrive early.',5.4,'medium')
    p.text(17,190,'Times shown are khutbah start times.',5.4,'regular','soft')
    p.text(280,190,'hbic.ca/prayer-times',5.4,'medium','teal','right')
    return p

def draw_geometry(photo_file,out):
    geo=cfg['photos'][photo_file]; im=Image.open(root/'references'/photo_file).convert('RGB')
    d=ImageDraw.Draw(im);font=ImageFont.truetype(str(fonts['bold']),16)
    for side,color in [('left','#14D1E2'),('right','#ECC36D')]:
        quad=geo[side]; d.line([tuple(p) for p in quad+[quad[0]]],fill=color,width=3)
        for i,(x,y) in enumerate(quad):
            d.ellipse((x-4,y-4,x+4,y+4),fill=color)
            px=x+(12 if i in (0,3) else -122);py=y+(10 if i<2 else -31)
            d.rectangle((px-3,py-2,px+110,py+19),fill='#122F45')
            d.text((px,py),f'{side[0].upper()}{i+1}  {x},{y}',fill='white',font=font)
    x,y=geo['handle'];d.ellipse((x-22,y-22,x+22,y+22),outline='#FF9C6B',width=3)
    d.rectangle((14,14,min(im.width-14,450),46),fill='#122F45')
    d.text((23,21),'Photographic control points • pixels only',font=font,fill='white')
    im.save(out)

def showcase(pics,out):
    W=1680; H=572; board=Image.new('RGB',(W,H),'#F8F5EC');d=ImageDraw.Draw(board)
    d.text((35,22),'HBIC ENTRANCE  /  THREE STUDIES',font=ImageFont.truetype(str(fonts['bold']),23),fill='#082845')
    d.line([(35,62),(1645,62)],fill='#BA933F',width=2)
    for i,(name,im) in enumerate(pics):
        x=35+i*545
        crop=im.crop((332,25,1163,843));crop.thumbnail((520,440))
        board.paste(crop,(x+(520-crop.width)//2,82))
        d.text((x,528),name,font=ImageFont.truetype(str(fonts['bold']),22),fill='#082845')
    board.save(out)

def verify_qr(p,pdf,temp):
    # Crop codes from the actual PDF raster, not just the generated matrix.
    stem=temp/'qa';r=render(pdf,stem,144)
    report=[]
    for x,y,s,key in p.qrs:
        k=144/25.4
        crop=r.crop((int((x+bleed-2)*k),int((y+bleed-2)*k),math.ceil((x+bleed+s+2)*k),math.ceil((y+bleed+s+2)*k)))
        for width in [340,140,100]:
            test=ImageOps.contain(crop,(width,width),Image.Resampling.LANCZOS)
            decoded=zxingcpp.read_barcodes(test)
            assert len(decoded)==1 and decoded[0].text==links[key],(p.name,key,width,[q.text for q in decoded])
        report.append({'panel':p.name,'code':key,'decoded':links[key],'print_size_mm':s,'simulated_crop_px':[340,140,100]})
    return report

def design_guide(out,pages,mockwide,mockfull,checks):
    W,H=297*mm,210*mm
    c=canvas.Canvas(str(out),pagesize=(W,H),pageCompression=1);c.setTitle('A place to belong. | HBIC entrance design and installation')
    def label(x,y,s,text,f='regular',color='navy'):
        c.setFillColor(hx(color));c.setFont(f,s);c.drawString(x*mm,(210-y)*mm,text)
    def page(k,name,desc):
        c.setFillColor(hx('cream'));c.rect(0,0,W,H,fill=1,stroke=0)
        label(16,15,9,'HBIC  /  MASJID BILAL ENTRANCE','bold','teal')
        label(16,37,33,name,'display')
        label(16,48,10.5,desc,'regular','soft')
        c.setStrokeColor(hx('gold'));c.setLineWidth(.7);c.line(16*mm,154*mm,281*mm,154*mm)
        label(16,200,8.5,'DESIGN & INSTALLATION  •  PROVISIONAL DIMENSIONS  •  NOVEMBER 2026','bold','soft')
        label(270,200,9,str(k).zfill(2),'bold','teal')
    def pic(im,x,y,w,h):
        iw,ih=im.size; s=min(w/iw,h/ih);pw,ph=iw*s,ih*s
        from reportlab.lib.utils import ImageReader
        c.drawImage(ImageReader(im),x*mm,(210-y-ph)*mm,pw*mm,ph*mm)
    def block(x,y,title,lines):
        label(x,y,13,title,'bold','teal')
        for i,line in enumerate(lines):label(x,y+8+i*5.2,9.8,line)
    page(1,'A place to belong.','An entrance identity for Hazrat Bilal Islamic Centre, Calgary.')
    pic(mockwide,16,61,181,128)
    block(203,75,'The wide band',[
      'A warm, legible welcome on the left.',
      'The digital companion on the right.',
      'Only the institution name reads',
      'across the opening. Everything else',
      'remains complete on its own leaf.',
      'The panel shape steps around the',
      'right handle and its working area.'])
    label(203,144,9.5,'PROVISIONAL COMBINED RATIO','bold','teal')
    label(203,159,25,f'{(pages["wide"][0].w+pages["wide"][1].w+door["centre_gap"]+2*edge["seam_each_side"])/pages["wide"][0].h:.2f}:1','display')
    c.showPage()
    page(2,'Design system','Six columns per leaf. One shared name baseline and divider.')
    block(16,70,'Left leaf: the essential read',[
      'Official seal and Masjid Bilal name.',
      'Welcome headline, daily prayer information,',
      'website QR, address and office contact.',
      'Read the left leaf as a complete sign.'])
    block(104,70,'Right leaf: the digital read',[
      'Official app, iPhone and Android.',
      'Download and prayer QR codes.',
      'Verified HBIC Youth social handles.',
      'Keep every scan point away from hardware.'])
    block(194,70,'Type and image',[
      'Newsreader display: welcome and app line.',
      'Inter: identity, utilities and labels.',
      'Original 500 px circular seal at 121 mm:',
      'approximately 105 effective ppi.',
      'No invented logo artwork or imagery.'])
    for i,(n,key) in enumerate([('Warm paper','cream'),('HBIC navy','navy'),('Teal','teal'),('Quiet brass','gold')]):
        x=16+66*i;c.setFillColor(hx(key));c.rect(x*mm,43*mm,58*mm,23*mm,fill=1,stroke=0)
        label(x,175,10,n,'bold');label(x,181,9,col(key),'regular','soft')
    label(16,188,8.6,'RGB appearance reference. Convert through the vendor’s approved substrate profile and check the physical proof.','regular','soft')
    c.showPage()
    page(3,'Fit and installation','Set the final artwork from measured leaf faces and the vendor’s approved clearances.')
    block(16,70,'01  Measure on site',[
      'Record each leaf width and usable height in mm.',
      'Measure seam and frame reveals when closed.',
      'Trace handle swing, lock, closer and lower hardware.',
      'Check unit 26, door seals, inspection labels and glass.',
      'Confirm the substrate, adhesive and building approval.'])
    block(16,115,'02  Rebuild the export',[
      'Edit measurements/Entrance.json with actual values.',
      'Keep each printed half and its contour independent.',
      'Request the official vector logo if the vendor needs',
      'higher effective resolution for close viewing.',
      'Check 1:1 dimensions and trim/bleed boxes.'])
    block(152,70,'03  Proof and place',[
      'Clean and test a small hidden section of the coating.',
      'Use a matte, compatible removable sign film if approved.',
      'Print a material swatch and a 1:1 QR trial.',
      'Confirm the type and scans at the actual approach distance.',
      'Dry-fit both panels with doors shut, then open and latch.'])
    block(152,115,'04  Finish',[
      'Use only vendor-approved contours; remove bleed after trim.',
      'No film bridges the seam or runs onto frames or glass.',
      'Leave operating hardware and required signs fully exposed.',
      'Keep the optional Jumu’ah insert replaceable and separate.',
      'No installation is authorized by this prototype.'])
    label(16,170,9.5,'5 mm bleed is included on each panel PDF. Trim diagrams are separate; do not print guides as artwork.','bold')
    label(16,179,9.5,'The source drawing uses the photos for projection, not as a measurement of physical size.','regular','soft')
    c.showPage()
    page(4,'Full-door alternative','A larger option using the same identity and a taller composition, without stretching the band.')
    pic(mockfull,16,61,181,127)
    block(203,74,'More vertical presence',[
      'Full-door panels extend below the',
      'handle, with a dedicated cutout.',
      'A second relief clears lower hardware.',
      'Temporary notices and changing',
      'prayer schedules stay off the film.',
      'Use only if site dimensions and door',
      'finish support the larger coverage.'])
    c.showPage()
    page(5,'Proof and scan','Every QR was decoded independently from the exported print PDF.')
    block(16,70,'Actual destinations',[
      'Website QR  /  https://hbic.ca',
      'Download QR  /  https://hbic.ca/download',
      'Prayer QR  /  https://hbic.ca/prayer-times',
      'QRs use black modules, white quiet zones and no overlays.'])
    block(16,111,'Print test sequence',[
      'Open the A4 proof. Pages 1–2 show the whole layout at 1:10.',
      'The remaining pages tile Option A at 1:1 with 8 mm overlap.',
      'Use Actual size (100%); check the printed 50 mm reference.',
      'Scan the physical proof at 0.5 m, 1 m and 1.5 m on iPhone/Android.',
      'Test in the actual corridor under the real lighting.'])
    block(152,70,'Digital checks completed',[
      f'{len(checks)} QR placements across both print options.',
      'Crops at 340, 140 and 100 px decoded to the exact URLs.',
      'Digital downsampling is not a physical distance test.',
      'Confirm the scale and scanning on the printed proof.'])
    block(152,111,'Printer handoff',[
      'Panel PDFs contain embedded text and vector QRs.',
      'The seal is original raster art; no upscaling is claimed.',
      'Use the separate contour sheets as technical references.',
      'Artwork is RGB with process-black QR modules.',
      'Vendor to confirm colour conversion and installation spec.'])
    c.showPage();c.save()

def main():
    checks=[]
    with tempfile.TemporaryDirectory(prefix='hbic-signage-') as t:
        tmp=Path(t);pics=[]
        for style in styles:
            pp=[layout('wide',side,style) for side in ('Left','Right')]
            images=[]
            for i,p in enumerate(pp):
                export_pdf(p,tmp/f'concept-{i}.pdf')
                images.append(render(tmp/f'concept-{i}.pdf',tmp/f'concept-{i}',48))
            pic=mock('Reference 3.png',pp,images,'wide')
            pic.save(root/'concepts'/f'{style} - Entrance.jpg',quality=94)
            pics.append((style,pic))
        showcase(pics,root/'concepts/Three entrance studies.png')
        pages={}
        for which,lab in [('wide','A Wide Band'),('full','B Full Door')]:
            pp=[layout(which,side) for side in ('Left','Right')]
            pages[which]=pp; rr=[]
            for side,p in zip(['Left','Right'],pp):
                pdf=root/'print'/f'{lab} - {side} Panel.pdf'
                export_pdf(p,pdf,True)
                svg(p,root/'exports'/f'{lab} - {side} Panel.svg')
                # Actual-size plotter reference; no mark is embedded in artwork.
                contour=' '.join(f'{x+bleed},{y+bleed}' for x,y in p.shape)
                cw,ch=p.w+2*bleed,p.h+2*bleed
                (root/'measurements'/f'{lab} - {side} Trim Contour.svg').write_text(
                    f'<svg xmlns="http://www.w3.org/2000/svg" width="{cw}mm" height="{ch}mm" viewBox="0 0 {cw} {ch}"><title>Provisional contour, same origin as PDF bleed box; vendor to verify on site</title><polygon points="{contour}" fill="none" stroke="#ff00ff" stroke-width="0.25"/></svg>')
                export_pdf(p,tmp/f'{side}.pdf')
                rr.append(render(tmp/f'{side}.pdf',tmp/side,96))
                checks+=verify_qr(p,pdf,tmp)
                page=PdfReader(pdf).pages[0]
                assert abs(float(page.trimbox.width)/mm-p.w)<.01 and abs(float(page.trimbox.height)/mm-p.h)<.01
            # Combined review PNGs retain real split, not a single sheet for production.
            pair_pdf(*pp,tmp/'Pair.pdf')
            render(tmp/'Pair.pdf',root/'exports'/f'{lab} - Combined',90)
            out=mock('Reference 3.png',pp,rr,which)
            out.save(root/'mockups'/f'{lab} - Front Entrance.jpg',quality=95)
            if which=='wide':
                mock('Reference 1.png',pp,rr,which).save(root/'mockups'/'A Wide Band - Corridor View.jpg',quality=95)
                out.crop((372,64,1157,640)).save(root/'mockups'/'A Wide Band - Entrance Detail.jpg',quality=97)
                # Two panels on a neutral ground, with the gap labeled as a mechanical separation.
                compare=Image.new('RGB',(1470,1000),'#DCE8E8')
                for i,im in enumerate(rr):
                    im=im.resize((round(im.width/im.height*800),800),Image.Resampling.LANCZOS)
                    p=pp[i]; alpha=Image.new('L',im.size)
                    ImageDraw.Draw(alpha).polygon([(x/p.w*(im.width-1),y/p.h*(im.height-1)) for x,y in p.shape],fill=255)
                    compare.paste(im,(20+i*735+(695-im.width)//2,75),alpha)
                d=ImageDraw.Draw(compare);f=ImageFont.truetype(str(fonts['bold']),26)
                d.text((30,25),'LEFT LEAF  /  PRIMARY',font=f,fill='#082845');d.text((765,25),'RIGHT LEAF  /  DIGITAL',font=f,fill='#082845')
                compare.save(root/'mockups'/'A Wide Band - Independent Panels.png')
                outwide=out
            else:outfull=out
            guide(which,root/'measurements'/f'{lab} - Cut and Fit Guide.pdf')
        for key in links:
            n=len(qr[key]);(root/'qr'/f'{key} QR.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}">{qr_svg_group(key,0,0,n)}</svg>')
        for i,photo in enumerate(cfg['photos']):
            draw_geometry(photo,root/'measurements'/f'Photo {i+1} - Geometry.png')
        a4_proof(pages,root/'print/A4 Tiled Proof - Wide Band.pdf')
        export_pdf(schedule(),root/'print/Jumuah Schedule - Replaceable A4.pdf')
        svg(schedule(),root/'exports/Jumuah Schedule - Editable.svg')
        pair_pdf(*pages['wide'],root/'exports/A Wide Band - Combined Proof.pdf')
        design_guide(root/'documentation/Design and Installation Guide.pdf',pages,outwide,outfull,checks)
        (root/'documentation/QR Validation.json').write_text(json.dumps(checks,indent=2)+'\n')
        print(json.dumps({'verified_qr_placements':len(checks),'panels':{k:[[p.w,p.h] for p in v] for k,v in pages.items()},'proof_pages':len(PdfReader(root/'print/A4 Tiled Proof - Wide Band.pdf').pages)},indent=2))

if __name__=='__main__':
    main()
