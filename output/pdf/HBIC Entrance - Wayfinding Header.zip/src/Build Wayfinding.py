"""HBIC Wayfinding Edition — editable artwork, trim contours, and photo proofs."""
from pathlib import Path
from fontTools.pens.boundsPen import BoundsPen
import base64, json, math, tempfile
from PIL import Image, ImageDraw, ImageOps
from reportlab.pdfgen import canvas
from pypdf import PdfReader
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
import Base as B

root=B.root
D=B.door
cfg=B.cfg
mm=B.mm
Ink='#112A42'; Rail='#102537'; Cobalt='#14427A'; Paper='#FBF4E8'
White='#FFFCF5'; Mint='#C6EBD9'; Signal='#FFB168'; Faint='#B5CBDB'
assets=root/'brand/Platform Marks'
apple=svg2rlg(str(assets/'Apple.svg'))
assert apple.width and apple.height

for key,settings in (
    ('sign-heavy',{'wght':800,'opsz':72,'wdth':100}),
    ('sign-medium',{'wght':635,'opsz':36,'wdth':100}),
):
    dst=root/'brand'/f'{key}.ttf'
    font=B.VarFont(root/'brand/Bricolage Variable.ttf')
    B.instantiateVariableFont(font,settings,inplace=True)
    name='HBIC '+key.title().replace('-',' ')
    for rec in list(font['name'].names):
        if rec.nameID in (1,4,6,16):
            font['name'].setName(name.replace(' ','-') if rec.nameID==6 else name,rec.nameID,rec.platformID,rec.platEncID,rec.langID)
        elif rec.nameID in (2,17):
            font['name'].setName('Regular',rec.nameID,rec.platformID,rec.platEncID,rec.langID)
    font.save(dst)
    B.fonts[key]=dst
    B.pdfmetrics.registerFont(B.TTFont(key,str(dst)))

def mark(p,name,x,y,h):
    path=assets/(name+'.'+('svg' if name=='Apple' else 'png'))
    if name=='Apple':
        ratio=apple.width/apple.height
    else:
        with Image.open(path) as im:
            ratio=im.width/im.height
    p.ops.append(('mark',x,y,h*ratio,h,path))
b=5
fit=cfg['threshold']
top=fit['top_mm']; bottom=fit['bottom_mm']; H=bottom-top
gap=D['centre_gap']+2*B.edge['seam_each_side']
inner=B.edge['seam_each_side']; outer=B.edge['outside']
# A provisional on-site safety envelope; proof masks follow each photograph.
handle=tuple(fit['handle_keep_out_art_mm'])
bolt=tuple(fit['bolt_keep_out_art_mm'][:3])+ (H,)

def label(p,x,y,s,sz=21,color=Ink):
    p.text(x,y,s,sz,'bold',color,track=1.25)

def display(p,x,y,s,sz,color=Ink,track=0.2):
    p.text(x,y,s,sz,'sign-heavy',color,track=track)

def body(p,x,y,s,sz=25,color=Ink,align='left',font='medium'):
    p.text(x,y,s,sz,font,color,align)

def rule(p,x1,x2,y,color=Ink,weight=1.6):
    p.line([(x1,y),(x2,y)],color,weight)

def bands(left):
    return [(0,154,Ink),(154,749,Cobalt if left else Paper),(749,956,Rail),
            (956,1525,Mint if left else Cobalt),(1525,H,Rail)]

def layout(left, show_tiktok=False):
    w=D['left_width' if left else 'right_width']-outer-inner
    p=B.Page(w,H,Ink,name=('Left' if left else 'Right')+' door | Wayfinding Edition')
    for y0,y1,colour in bands(left):
        p.rect(0,y0,w,y1-y0,colour)
    m=72
    # Treat the two leaves as a single line: shared baseline and a balanced gap at the seam.
    seam_margin=49
    p.text(w-seam_margin if left else seam_margin,111,
           'Hazrat Bilal' if left else 'Islamic Centre',
           102,'display-semibold',White,'right' if left else 'left',0.5)
    if left:
        p.image(m,218,118)
        # Orange registration stripe and oversized, left-aligned entrance wordmark.
        p.rect(w-25,154,25,595,Signal)
        label(p,218,262,'WELCOME',21,White)
        body(p,218,302,'Calgary, Alberta',25,Faint)
        display(p,m,527,'MASJID',166,White,1.1)
        display(p,m,708,'BILAL',183,Mint,1.1)
        body(p,m,859,'Prayer, learning and community',32,White)
        label(p,m,1042,'PRAYER AT MASJID BILAL',20,Ink)
        display(p,m,1140,'Five daily prayers',66)
        display(p,m,1224,'and Jumu’ah',66)
        rule(p,m,w-m,1268,'#699D90',1.5)
        display(p,m,1395,'hbic.ca',75)
        body(p,m,1440,'Visit our website',24,Ink)
        p.qr(w-m-115,1316,115,'Website')
        body(p,m,1614,'587-917-0333  ·  info@hbic.ca',25,White)
        body(p,m,1664,'20 Saddlestone Drive NE, Calgary',23,Faint)
    else:
        p.rect(0,154,17,595,Signal)
        label(p,m,240,'THE MASJID BILAL APP',21)
        display(p,m,355,'Your masjid.',88)
        display(p,m,453,'On your phone.',88)
        body(p,m,510,'Prayer times, alerts and masjid events',26)
        rule(p,m,w-m,542,'#B2A698',1.4)
        for x,key,caption in ((m,'App','Get the app'),(w/2+12,'Prayer times','Prayer times')):
            p.qr(x,578,112,key)
            body(p,x+133,645,caption,24)
        # Keep the store badges to the right of the lever clearance.
        body(p,340,799,'DOWNLOAD',18,White,font='bold')
        mark(p,'Apple',340,825,54)
        mark(p,'Google',536,825,54)
        body(p,340,924,'hbic.ca/download',25,Faint)
        label(p,m,1042,'COMMUNITY UPDATES',20,Signal)
        display(p,m,1139,'Follow Masjid Bilal',70,White)
        rule(p,m,w-m,1182,'#82A5BD',1.5)
        for i,(service,value) in enumerate((('Instagram','@hbicyouth'),('YouTube','@hbicyouth'),('TikTok','@hbicyouth'))):
            y=1254+i*89
            mark(p,service,m,y-(37 if service=='YouTube' else 44),32 if service=='YouTube' else 45)
            body(p,m+78,y,service,26,White)
            body(p,w-m,y,value,27,White,'right','bold')
            rule(p,m,w-m,y+25,'#82A5BD',.85)
        body(p,w-m,1638,'Masjid Bilal  ·  Calgary',26,White,'right')
    return p

def draw(c,p,x=0,y=0,s=mm,extra=0):
    c.saveState(); c.translate(x,y); c.scale(s,s)
    for start,end,colour in bands(p.name.startswith('Left')):
        if start==0: start-=extra
        if end==H: end+=extra
        c.setFillColor(B.hx(colour))
        c.rect(-extra,H-end,p.w+2*extra,end-start,fill=1,stroke=0)
    blank=B.Page(p.w,p.h,p.bg)
    class Proxy:
        def __init__(self,c): self.c=c; self.first=True
        def rect(self,*a,**kw):
            if self.first:self.first=False
            else:self.c.rect(*a,**kw)
        def __getattr__(self,k): return getattr(self.c,k)
    def flush():
        if blank.ops:
            B.draw(Proxy(c),blank,clip=False);blank.ops=[]
    for op in p.ops:
        if op[0]=='mark':
            flush()
            _,xx,yy,ww,hh,path=op
            if path.suffix=='.svg':
                c.saveState();c.translate(xx,p.h-yy-hh);c.scale(ww/apple.width,hh/apple.height)
                renderPDF.draw(apple,c,0,0);c.restoreState()
            else:
                c.drawImage(str(path),xx,p.h-yy-hh,ww,hh,mask='auto')
        else:
            blank.ops.append(op)
    flush()
    c.restoreState()

def pdf_page(p,path,bleed=0):
    c=canvas.Canvas(str(path),pagesize=((p.w+2*bleed)*mm,(p.h+2*bleed)*mm),pageCompression=1)
    c.setTitle(p.name)
    if bleed:
        c.setTrimBox((bleed*mm,bleed*mm,(p.w+bleed)*mm,(p.h+bleed)*mm))
        c.setBleedBox((0,0,(p.w+2*bleed)*mm,(p.h+2*bleed)*mm))
    draw(c,p,bleed*mm,bleed*mm,extra=bleed);c.showPage();c.save()

def editable(p,path):
    # Base exports editable text with embedded type and a complete set of vector primitives.
    q=B.Page(p.w,p.h,p.bg,name=p.name)
    q.ops=[op if op[0] not in ('poly','mark') else ('rect',0,0,0,0,f'#a{idx:05x}') for idx,op in enumerate(p.ops)]
    B.svg(q,path)
    s=path.read_text()
    for idx,(kind,*args) in enumerate(p.ops):
        if kind=='poly':
            coords,color=args
            s=s.replace(f'<rect x="0" y="0" width="0" height="0" fill="#a{idx:05x}"/>',
                f'<polygon points="{" ".join(f"{x:.3f},{y:.3f}" for x,y in coords)}" fill="{color}"/>')
        if kind=='mark':
            x,y,w,h,asset_path=args
            mime='image/svg+xml' if asset_path.suffix=='.svg' else 'image/png'
            s=s.replace(f'<rect x="0" y="0" width="0" height="0" fill="#a{idx:05x}"/>',
                f'<image x="{x}" y="{y}" width="{w}" height="{h}" href="data:{mime};base64,{base64.b64encode(asset_path.read_bytes()).decode()}"/>')
    assert 'width="0" height="0"' not in s
    path.write_text(s)

def contours(p,right):
    if not right:return f'M0 0H{p.w}V{H}H0Z'
    # Continuous outer cut path with shallow near-seam access, only where necessary.
    _,at,ax,ab=handle
    _,bt,bx,_=bolt
    r=17
    return (f'M0 0H{p.w}V{H}H{bx}V{bt+r}Q{bx} {bt} {bx-r} {bt}H0V{ab}H{ax-r}'
            f'Q{ax} {ab} {ax} {ab-r}V{at+r}Q{ax} {at} {ax-r} {at}H0Z')

def trim_svg(p,path,right):
    path.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{p.w}mm" height="{H}mm" viewBox="0 0 {p.w} {H}"><title>Provisional cut path. Verify on site before fabrication.</title><path d="{contours(p,right)}" fill="none" stroke="#ff00a0" stroke-width="0.5"/></svg>')

def mock(photo_name,panels,rasters):
    g=cfg['photos'][photo_name]
    photo=Image.open(root/'references'/photo_name).convert('RGB')
    im=B.photo_clean(photo,g)
    for i,(p,art) in enumerate(zip(panels,rasters)):
        side=('left','right')[i];dw=D[side+'_width'];x=(outer,inner)[i]
        T=B.homography([(0,0),(dw,0),(dw,D['height']),(0,D['height'])],g[side])
        dest=B.points(T,[(x,top),(x+p.w,top),(x+p.w,bottom),(x,bottom)])
        art=art.convert('RGBA'); art.thumbnail((920,1450),Image.Resampling.LANCZOS)
        rw,rh=art.size
        art=Image.blend(art,Image.new('RGBA',art.size,(77,62,49,255)),.047)
        if i:
            inv=B.np.linalg.inv(T); d=ImageDraw.Draw(art)
            # Show the visual result of a close field fit. The separate contour
            # intentionally leaves more room when that close fit is not possible.
            iswide=photo_name=='Reference 3.png'
            if iswide:
                lock=(787.0,494.3,17.2,17.6)
                lever=[(787,486),(800,489),(806,495),(827,495),(827,501),(821,508),(801,507),(790,508)]
                lower=(784,785,7,22)
            else:
                lock=(473.8,828.4,15.8,15.6)
                lever=[(473,822),(486,824),(493,829),(508,829),(511,832),(505,839),(481,839),(471,837)]
                lower=(476,1079,8,22)
            def project(points):
                return [((a-x)/p.w*rw,(y-top)/H*rh) for a,y in B.points(inv,points)]
            def oval(ellipse):
                a,y,rx,ry=ellipse
                return [(a+rx*math.cos(j*math.tau/48),y+ry*math.sin(j*math.tau/48)) for j in range(48)]
            for shape in (oval(lock),lever,oval(lower)):
                d.polygon(project(shape),fill=(0,0,0,0))
        im=Image.alpha_composite(im,B.warp(art,B.homography([(0,0),(rw,0),(rw,rh),(0,rh)],dest),photo.size))
    return im.convert('RGB')

def combined(pages,out):
    l,r=pages
    c=canvas.Canvas(str(out),pagesize=((l.w+gap+r.w)*mm,H*mm),pageCompression=1)
    c.setTitle('HBIC Wayfinding Edition | Combined artwork')
    c.setFillColor(B.hx('#3D3836'));c.rect(0,0,(l.w+gap+r.w)*mm,H*mm,fill=1,stroke=0)
    draw(c,l);draw(c,r,(l.w+gap)*mm)
    c.showPage();c.save()

def pdf_heading(c,title,sub):
    c.setFillColor(B.hx(Ink));c.setFont('display-semibold',21);c.drawString(13*mm,278*mm,title)
    c.setFont('regular',8);c.drawString(13*mm,271*mm,sub)
    c.setStrokeColor(B.hx('#8A7E70'));c.line(13*mm,267*mm,197*mm,267*mm)

def scale_bar(c,x=13,y=19):
    c.setStrokeColor(B.hx(Ink));c.line(x*mm,y*mm,(x+50)*mm,y*mm)
    for end in (x,x+50):c.line(end*mm,(y-1)*mm,end*mm,(y+1)*mm)
    c.setFillColor(B.hx(Ink));c.setFont('regular',8);c.drawString((x+54)*mm,(y-1)*mm,'50 mm ruler check')

def guide(pages,out):
    c=canvas.Canvas(str(out),pagesize=(210*mm,297*mm),pageCompression=1)
    pdf_heading(c,'Wayfinding Edition','HBIC  /  Entrance signage  /  Design and installation')
    l,r=pages
    factor=1/10; leftx=(210-(l.w+r.w+gap)*factor)/2; y=82
    draw(c,l,leftx*mm,y*mm,mm*factor)
    rightx=leftx+(l.w+gap)*factor
    draw(c,r,rightx*mm,y*mm,mm*factor)
    c.setStrokeColor(B.hx('#FF91BF'));c.setLineWidth(.8);c.setDash(3,2)
    for a,bb,x2,bb2 in (handle,bolt):
        c.rect((rightx+a*factor)*mm,(y+(H-bb2)*factor)*mm,(x2-a)*factor*mm,(bb2-bb)*factor*mm,fill=0,stroke=1)
    c.setDash()
    rows=[
        f'Left {l.w} × {H} mm  /  Right {r.w} × {H} mm  /  5 mm bleed each edge.',
        '1:10 overview. Pink rectangles show estimated hardware keep-outs on the right leaf.',
        'Confirm all dimensions on site: the door faces, plate numbers, seam, handle sweep and bottom bolt.',
        'Dry-fit both sides level. Keep the centre seam, hardware, frame and sidelight fully clear.',
        'Cut contours are provisional. Match to hardware with the installer before cutting or printing.',
        'Specify matte removable architectural film; check adhesion and proof the colours on the actual stock.',
        'Supply 1:1 PDFs plus separate SVG contours. No cutting line is printed in the art.'
    ]
    for i,row in enumerate(rows):
        c.setFont('regular',8);c.setFillColor(B.hx(Ink));c.drawString(13*mm,(73-i*7)*mm,row)
    scale_bar(c);c.showPage()
    pdf_heading(c,'Artwork and fit','HBIC  /  Colour, type and final proof')
    rows=[
        ('Composition','Only the name is paired across the doors. All other content belongs to one leaf.'),
        ('Left leaf','Official circular mark, welcome, daily prayers and Jumu’ah, website and contact.'),
        ('Right leaf','Official app, prayer-times QR and social channels. The app is for iPhone and Android.'),
        ('Colour','Cobalt, mint and cream with an orange edge stripe. Dark bands sit behind the hardware.'),
        ('Type','Newsreader in the header, Bricolage Grotesque in the panels, Inter for details. Fonts are embedded.'),
        ('Raster mark','Original 500 px seal, printed at 118 mm, about 108 ppi. Review at size.'),
        ('QR codes','Black vector modules and four-module white quiet zones. Scan a printed sample.'),
        ('Time-sensitive notice','Use the separate replaceable Jumu’ah insert; it is not part of the wrap.'),
        ('Print proof','Convert to your shop’s output profile and approve a stock swatch and 1:1 QR sample.'),
        ('Platform artwork','Official Instagram, YouTube and TikTok marks appear beside @hbicyouth.'),
        ('Photo references','Mockups show a close field fit. Final openings may differ; use the measured cut guide.'),
    ]
    for i,(label,body) in enumerate(rows):
        yy=(254-i*17)*mm;c.setFillColor(B.hx(Cobalt));c.setFont('bold',10);c.drawString(13*mm,yy,label)
        c.setFillColor(B.hx(Ink));c.setFont('regular',8.5);c.drawString(13*mm,yy-5*mm,body)
    c.showPage();c.save()

def tiled(pages,out):
    c=canvas.Canvas(str(out),pagesize=(210*mm,297*mm),pageCompression=1)
    c.setTitle('HBIC Wayfinding Edition | A4 tiled proof')
    l,r=pages
    pdf_heading(c,'A4 proof: both doors','1:10 overview followed by 1:1 tiles. Use Actual Size (100%), never Fit.')
    s=mm/10;x=(210-(l.w+gap+r.w)/10)*mm/2;y=77*mm
    draw(c,l,x,y,s);draw(c,r,x+(l.w+gap)*s,y,s)
    scale_bar(c);c.showPage()
    for idx,p in enumerate(pages):
        tile_w,tile_h,overlap=188,244,8
        dx,dy=tile_w-overlap,tile_h-overlap
        ncol=math.ceil((p.w-overlap)/dx);nrow=math.ceil((p.h-overlap)/dy)
        form=f'Leaf{idx}'
        c.beginForm(form,0,0,p.w*mm,p.h*mm);draw(c,p);c.endForm()
        for i in range(nrow):
            for j in range(ncol):
                leaf='Left' if idx==0 else 'Right'
                pdf_heading(c,f'{leaf} / row {i+1} / column {j+1}',f'{nrow} rows × {ncol} columns  ·  8 mm overlap  ·  Actual Size (100%)')
                x,y=11*mm,17*mm
                c.saveState();cl=c.beginPath();cl.rect(x,y,tile_w*mm,tile_h*mm);c.clipPath(cl,stroke=0)
                c.translate(x-j*dx*mm,y+(tile_h-p.h+i*dy)*mm);c.doForm(form);c.restoreState()
                c.setStrokeColor(B.hx(Ink));c.setLineWidth(.5)
                for a in (0,tile_w):
                    for z in (0,tile_h):
                        xx,yy=x+a*mm,y+z*mm
                        c.line(xx-2*mm,yy,xx+2*mm,yy);c.line(xx,yy-2*mm,xx,yy+2*mm)
                scale_bar(c,13,9);c.showPage()
    c.save()

def glyph_box(op, font_cache):
    _,x,y,label,size,font,_,tracking=op
    face=font_cache[font]
    cmap=face.getBestCmap()
    glyphs=face.getGlyphSet()
    units=face['head'].unitsPerEm
    cursor=0
    box=[]
    for ch in label:
        key=cmap[ord(ch)]
        pen=BoundsPen(glyphs)
        glyphs[key].draw(pen)
        if pen.bounds:
            a,b,c,d=pen.bounds
            box.append((x+cursor+a*size/units,y-d*size/units,x+cursor+c*size/units,y-b*size/units))
        cursor+=face['hmtx'][key][0]*size/units+tracking
    return (label,min(q[0] for q in box),min(q[1] for q in box),max(q[2] for q in box),max(q[3] for q in box))

def main():
    pages=(layout(True),layout(False))
    assert all(p.h==H and p.w>800 for p in pages)
    assert top>=cfg['hardware_mm']['left_unit_26']['keep_clear_until_y']
    assert bottom<=D['height']-B.edge['bottom_minimum']
    qa=[]
    face_cache={f:B.VarFont(v) for f,v in B.fonts.items()}
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp);rasters=[]
        for i,p in enumerate(pages):
            side=('Left','Right')[i]
            text_boxes=[glyph_box(op,face_cache) for op in p.ops if op[0]=='text']
            for label,x0,y0,x1,y1 in text_boxes:
                assert 42<x0<x1<p.w-42 and 28<y0<y1<H-26,(label,x0,y0,x1,y1)
            for j,(label,x0,y0,x1,y1) in enumerate(text_boxes):
                for label2,a0,b0,a1,b1 in text_boxes[j+1:]:
                    if min(x1,a1)-max(x0,a0)>1 and min(y1,b1)-max(y0,b0)>1:
                        raise AssertionError((label,label2))
                if i:
                    for ax,ay,bx,by in (handle,bolt):
                        assert min(x1,bx)<=max(x0,ax) or min(y1,by)<=max(y0,ay),(label,'hardware')
            for x,y,s,key in p.qrs:
                assert 42<=x and x+s<=p.w-42 and 0<=y and y+s<=H
                for label,x0,y0,x1,y1 in text_boxes:
                    assert min(x+s,x1)<=max(x,x0) or min(y+s,y1)<=max(y,y0),(key,label)
            pdf=root/f'print/{side} Door - Print.pdf'
            pdf_page(p,pdf,b)
            editable(p,root/f'exports/{side} Door - Editable.svg')
            trim_svg(p,root/f'measurements/{side} Door - Trim Contour.svg',i==1)
            qa+=B.verify_qr(p,pdf,tmp)
            page=PdfReader(pdf).pages[0]
            assert abs(float(page.trimbox.width)/mm-p.w)<.02
            assert abs(float(page.trimbox.height)/mm-H)<.02
            assert abs(float(page.bleedbox.width)/mm-(p.w+10))<.02
            desc=[f.get_object().get('/FontDescriptor') for f in page['/Resources']['/Font'].get_object().values()]
            assert sum('/FontFile2' in d.get_object() for d in desc if d)>=3
            pdf_page(p,tmp/f'{side}.pdf')
            rasters.append(B.render(tmp/f'{side}.pdf',tmp/side,42))
        combined(pages,root/'exports/Wayfinding - Combined Artwork.pdf')
        B.render(root/'exports/Wayfinding - Combined Artwork.pdf',root/'exports/Wayfinding - Combined Artwork',66)
        front=mock('Reference 3.png',pages,rasters)
        front.save(root/'mockups/Wayfinding - Actual Entrance.jpg',quality=96)
        close=mock('Reference 1.png',pages,rasters)
        close.save(root/'mockups/Wayfinding - Corridor View.jpg',quality=95)
        front.crop((380,45,1160,833)).save(root/'mockups/Wayfinding - Door Detail.jpg',quality=97)
        for key in B.qr:
            (root/f'qr/{key} QR.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'+B.qr_svg_group(key,0,0,100)+'</svg>')
        (root/'documentation/QR Validation.json').write_text(json.dumps(qa,indent=2)+'\n')
        guide(pages,root/'documentation/Design and Installation Guide.pdf')
        tiled(pages,root/'print/A4 Tiled Proof.pdf')
        review=layout(False, show_tiktok=True)
        review_pdf=root/'exports/Right Door - With TikTok Logo - Review Only.pdf'
        pdf_page(review,review_pdf,b)
        assert len(B.verify_qr(review,review_pdf,tmp))==2
        editable(review,root/'exports/Right Door - With TikTok Logo - Editable.svg')
        combined((pages[0],review),tmp/'Wayfinding Social Review.pdf')
        B.render(tmp/'Wayfinding Social Review.pdf',root/'exports/Wayfinding - With All Logos - Review',47)

    manifest={'status':'Provisional geometry; site measurement and printer proof required.',
              'panel_top_mm':top,'panel_bottom_mm':bottom,'trim_mm':[[p.w,p.h] for p in pages],
              'centre_visual_gap_mm':gap,'bleed_mm':b,
              'right_handle_keep_out_in_art_mm':handle,'right_bottom_keep_out_in_art_mm':bolt,
              'installed_panel_widths_are_based_on_photographs':True}
    (root/'measurements/Wayfinding Fit.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'geometry':manifest,'qr':qa},indent=2))

if __name__=='__main__':main()
