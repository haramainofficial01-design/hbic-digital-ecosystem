# Publisher artwork

- [Apple App Store](https://developer.apple.com/app-store/marketing/guidelines/): official English black badge from Apple's marketing badge endpoint.
- [Google Play](https://partnermarketinghub.withgoogle.com/brands/google-play/google-play/lockups-icons-badges/): official English badge; only its transparent outer padding was trimmed.
- [Instagram](https://www.meta.com/brand/resources/instagram/instagram-brand/): gradient glyph from Meta's Instagram Brand Asset Pack.
- [YouTube](https://brand.youtube/youtube-icon/): red icon from YouTube's publisher pack.
- [TikTok](https://developers.tiktok.com/docs/en/getting-started-design-guidelines): full-colour icon from the Developer Portal Logo Pack, used with the @hbicyouth handle.
- [Bricolage Grotesque](https://github.com/google/fonts/tree/main/ofl/bricolagegrotesque): SIL Open Font License, included.
