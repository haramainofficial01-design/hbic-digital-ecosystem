# HBIC Entrance · Wayfinding Edition / updated header

The full-height panels use cobalt, mint, warm white and orange. All copy, marks and QR codes stay on one door, except for the paired centre name.

- Start with the Wayfinding actual-entrance mockup or combined artwork.
- Use the two print PDFs with the separate SVG contours and the installation guide.
- The right door includes official Apple App Store and Google Play badges, plus Instagram, YouTube and TikTok logos. The three social handles are @hbicyouth.

The provisional trims are 866 × 1,740 mm left and 896 × 1,740 mm right, with 5 mm bleed. Verify actual sizes, hardware, seam and door swing before printing or cutting. Approve a printed colour and QR proof.

All three QR codes were decoded from the output PDFs. The A4 tiled proof starts with a 1:10 overview and then 1:1 sheets; use Actual Size. Install the packages in src/Requirements.txt and Poppler, then run python "src/Build Wayfinding.py" to regenerate the package.
